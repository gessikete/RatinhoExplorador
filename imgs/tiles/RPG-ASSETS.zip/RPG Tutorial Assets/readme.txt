This pixel pack was made by isaiah658. Everything included is licenced as Creative Commons 0 (CC0). Credit isn't required but is appreciated. I hope you enjoy using them and if you do use them please let me know by sending my a message on open game art http://opengameart.org/users/isaiah658

Tilemap by redfoc.

Get free game assets, tutorials, game templates http://redfoc.com